
Kray++ Launcher — Private App Assets & Starter Project
----------------------------------------------------

What you got:
- App icon variants (neon blue, cyberpunk, block, kraken) in assets/icons/
- A starter Flutter project (flutter_project/) with main.dart demonstrating UI
- README and guidance to build APK locally using Flutter or Android Studio

Features planned for the Kray++ App (you requested everything):
- Resource Pack Installer (one-tap install of packaged .mcpack files)
- Pack Preview and Previews of ore textures and UI
- Pack Builder: generates .mcpack variants (X-Ray only, Fullbright, Combo)
- Auto-backup and replace old packs
- Private updater for Kray++ packs
- Themes: Neon (default), Cyberpunk, Block, Kraken
- App Lock (PIN protected)
- Offline mode and local apk (private distribution)

Important: The app will NOT inject or modify Minecraft's binary or memory.
It will manage .mcpack files and install them into device storage for Minecraft to import.
This is safe and EULA-friendly.

How to build the Flutter app:
1. Install Flutter SDK on your PC. (https://flutter.dev)
2. Copy the flutter_project folder into a new Flutter app directory.
3. Place assets/icons into flutter_project/assets/ and declare them in pubspec.yaml.
4. Run: flutter pub get
5. Run: flutter build apk --release
6. Transfer APK to your Android device and install (Enable unknown sources if needed).

If you want, I can:
- Generate a ready-to-install APK (you must confirm you accept private APK and we will not distribute via Play Store).
- Expand the pack builder to actually output .mcpack files inside the app (I can produce the Dart code for that).
- Create higher-res icon variants or adaptive icons for Android (foreground/background).

