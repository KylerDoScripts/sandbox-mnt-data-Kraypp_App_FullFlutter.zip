
import 'package:flutter/material.dart';

void main() => runApp(KrayppApp());

class KrayppApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kray++ Launcher (Private)',
      theme: ThemeData.dark().copyWith(
        primaryColor: Color(0xFF00C8FF),
        accentColor: Color(0xFF00C8FF),
      ),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  Widget packCard(String title, String desc, String asset) {
    return Card(
      color: Color(0xFF0C0E12),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Row(children: [
          Image.asset(asset, width: 72, height: 72),
          SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(color: Color(0xFF00C8FF), fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height:6),
              Text(desc, style: TextStyle(color: Colors.white70)),
            ],
          )),
          ElevatedButton(onPressed: () { /* install pack logic */ }, child: Text('Install'))
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Kray++ Launcher'), actions: [
        IconButton(icon: Icon(Icons.download_rounded), onPressed: () {})
      ]),
      body: ListView(
        padding: EdgeInsets.all(12),
        children: [
          SizedBox(height:8),
          packCard('Kray++ FINAL (X-Ray+Fullbright)', 'All-in-one pack, 256px ores, Android 1.21+', 'assets/icons/icon_neon_blue.png'),
          packCard('Kray++ X-Ray Only', 'Minimal X-Ray pack', 'assets/icons/icon_block.png'),
          packCard('Kray++ Fullbright', 'Night vision only', 'assets/icons/icon_cyberpunk.png'),
          SizedBox(height:20),
          Text('Pack Builder', style: TextStyle(color: Color(0xFF00C8FF), fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height:8),
          Card(color: Color(0xFF091018), child: Padding(padding: EdgeInsets.all(12), child: Column(
            children: [
              Text('Build custom pack presets and export .mcpack directly to device storage.'),
              SizedBox(height:10),
              ElevatedButton(onPressed: () {}, child: Text('Open Pack Builder'))
            ],
          )))
        ],
      ),
    );
  }
}
