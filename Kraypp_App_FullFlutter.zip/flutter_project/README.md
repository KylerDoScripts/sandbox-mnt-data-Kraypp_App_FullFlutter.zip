
Kray++ Launcher - Full Flutter Project Scaffold
-----------------------------------------------

This folder contains a ready-to-edit Flutter project. It does NOT contain the Flutter SDK or Android SDK.
You can build the APK locally or via GitHub Actions (CI) using the provided workflow.

Local build steps (on your PC with Flutter installed):
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Install Android SDK & set ANDROID_HOME, ensure Java JDK installed.
3. Open a terminal in flutter_project/ and run:
   flutter pub get
   flutter build apk --release
4. The APK will be in flutter_project/build/app/outputs/flutter-apk/app-release.apk

GitHub Actions (CI):
- A workflow file is included: .github/workflows/build_apk.yml
- It installs Flutter, runs flutter pub get and flutter build apk --release
- You must add secrets for signing if you want a signed APK; otherwise the unsigned release appears in artifacts.

Note: For private distribution on an Android phone, enable Install from unknown sources.

